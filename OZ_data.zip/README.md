# Oz

Book:

http://www.gutenberg.org/files/25519/25519-h/25519-h.htm


### Analysis notes:

First and last region in `ozcnt.txt` are blank spaces.
